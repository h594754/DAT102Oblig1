package no.hvl.dat102.adt;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import no.hvl.dat102.exceptions.EmptyCollectionException;

public abstract class KoeADTTest {

	// Referer til Koe
	private KoeADT<Integer> koe;
	
	
	private int e0 = 1;
	private int e1 = 2;
	private int e2 = 3; 
	private int e3 = 4;
	private int e4 = 5;
	
	protected abstract KoeADT<Integer> reset();
	
	@BeforeEach
	public void setup() {
		koe = reset();
	}
	
	@Test
	public void sjekkeAtKoeErTom() {
		assertTrue(koe.erTom());
	}
	
	@Test
	public void testInnKoe() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);
		
		try {
			assertEquals(e0, koe.utKoe());
			assertEquals(e1, koe.utKoe());
			assertEquals(e2, koe.utKoe());
			assertEquals(e3, koe.utKoe());
			assertEquals(e4, koe.utKoe());
			
		} catch (EmptyCollectionException e) {
			fail("feil" + e.getMessage());
		}
	}
	
	@Test
	public void testInnKoeMedDuplikater() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		koe.innKoe(e2);
		koe.innKoe(e3);
		koe.innKoe(e4);
		
		try {
			assertEquals(e2, koe.utKoe());
			assertEquals(e1, koe.utKoe());
			assertEquals(e1, koe.utKoe());
			assertEquals(e0, koe.utKoe());
		} catch(EmptyCollectionException e) {
			fail("feil" + e.getMessage());
		}
	}
	
	@Test
	public void utKoeInnKoe() {
		try {
			koe.innKoe(e2);
			koe.utKoe();
			koe.innKoe(e3);
			koe.innKoe(e4);
			koe.utKoe();
			assertEquals(e3, koe.utKoe());
		} catch (EmptyCollectionException e) {
			fail("feil" + e.getMessage());
		}
	}
	
	@Test
	public final void erIkkeTom() {
		koe.innKoe(e0);
		koe.innKoe(e1);
		assertFalse(koe.erTom());
	}
	
	@Test
	public void utInnErTom() {
		try { 
			koe.innKoe(e0);
			koe.utKoe();
			assertTrue(koe.erTom());
		} catch (EmptyCollectionException e) {
			fail("feil" + e.getMessage());
		}
	}
	
	@Test
	public void innUtErTom() {
		Assertions.assertThrows(EmptyCollectionException.class, () -> {
			koe.erTom();
		});
	}
	
}
